#pragma once
#import "vinhtran.hpp"
#import "loading.hxx"
#include <fstream>
#include <vector>
#include <algorithm>
#include <cmath>
#define FMT_HEADER_ONLY
#include "fmt/core.h"
#include <stdarg.h>

// Helper for string formatting
static std::string string_format(const std::string fmt, ...) {
    std::vector<char> str(100,'\0');
    va_list ap;
    while (1) {
        va_start(ap, fmt);
        auto n = vsnprintf(str.data(), str.size(), fmt.c_str(), ap);
        va_end(ap);
        if ((n > -1) && (size_t(n) < str.size())) {
            return str.data();
        }
        if (n > -1)
            str.resize(n + 1);
        else
            str.resize(str.size() * 2);
    }
    return str.data();
}

// إضافة دالة GetRainbowColor هنا
static ImColor GetRainbowColor(float speed = 1.0f, float saturation = 1.0f, float brightness = 1.0f) {
    float time = ImGui::GetTime() * speed;
    float hue = fmodf(time, 1.0f);
    
    // تحويل HSV إلى RGB
    float h = hue * 6.0f;
    float s = saturation;
    float v = brightness;
    
    int i = static_cast<int>(h);
    float f = h - i;
    float p = v * (1.0f - s);
    float q = v * (1.0f - s * f);
    float t = v * (1.0f - s * (1.0f - f));
    
    float r, g, b;
    switch (i % 6) {
        case 0: r = v; g = t; b = p; break;
        case 1: r = q; g = v; b = p; break;
        case 2: r = p; g = v; b = t; break;
        case 3: r = p; g = q; b = v; break;
        case 4: r = t; g = p; b = v; break;
        case 5: r = v; g = p; b = q; break;
        default: r = v; g = t; b = p; break;
    }
    
    return ImColor(r, g, b, 1.0f);
}

// بديل أبسط إذا كانت الدالة السابقة لا تعمل
static ImColor GetRainbowColorSimple(float speed = 1.0f) {
    float time = ImGui::GetTime() * speed;
    float r = sinf(time) * 0.5f + 0.5f;
    float g = sinf(time + 2.0f * 3.14159f / 3.0f) * 0.5f + 0.5f;
    float b = sinf(time + 4.0f * 3.14159f / 3.0f) * 0.5f + 0.5f;
    return ImColor(r, g, b, 1.0f);
}

extern ImFont* verdana_smol;
extern ImFont* pixel_big;
extern ImFont* pixel_smol;

enum AimTarget {
    HEAD,
    HEADv2,
    BODY
};

bool ignoreKnocked = false;
bool force = false;

struct Vars_t
{
    bool Enable = {};
    bool Aimbot = {};
    float AimFov = {};
    int AimCheck = {};
    int AimType = {};
    int AimWhen = {};
    bool isAimFov = {};
    const char *dir[4] = {"Always", "Fire and Scope", "Scope", "No Aim"};
    bool lines = {};
//    bool AimKill = {};
    bool istelekill = {};
    bool EnableGhost = {};

    AimTarget Target = HEAD;
    const char* targets[3] = {"Head", "Headv2", "Body(belly)"};

    bool Box = {};
    bool Outline = {};
    bool Distance = {};
    bool fovaimglow = {};
    bool circlepos = {};
    bool skeleton = {};
    bool Name = {};
    bool Health = {};
    bool OOF = {};
    int CurrentTab = 0;
    bool enemycount = {};
    float fovLineColor[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    float espColor[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    ImVec4 boxColor = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    float AimSpeed = 0.0f;

    bool  isfly       = false;    
    float flySpeed    = 2.5f;      
    float flyHeight   = 15.0f;    

} Vars;

class game_sdk_t
{
public:
    void init();
    int (*GetHp)(void *player);
    void *(*Curent_Match)();
    void *(*GetLocalPlayer)(void *Game);
    void *(*GetHeadPositions)(void *player);
    Vector3 (*get_position)(void *player);
    void *(*Component_GetTransform)(void *player);
    void *(*get_camera)();
    Vector3 (*WorldToScreenPoint)(void *, Vector3);
    bool (*get_isVisible)(void *player);
    bool (*get_isLocalTeam)(void *player);
    bool (*get_IsDieing)(void *player);
    int (*get_MaxHP)(void *player);
    Vector3 (*GetForward)(void *player);
    void (*set_aim)(void *player, Quaternion look);
    bool (*get_IsSighting)(void *player);
    bool (*get_IsFiring)(void *player);
    monoString *(*name)(void *player);

    void *(*_GetHeadPositions)(void *);
    void *(*_newHipMods)(void *);
    void *(*_GetLeftAnkleTF)(void *);
    void *(*_GetRightAnkleTF)(void *);
    void *(*_GetLeftToeTF)(void *);
    void *(*_GetRightToeTF)(void *);
    void *(*_getLeftHandTF)(void *);
    void *(*_getRightHandTF)(void *);
    void *(*_getLeftForeArmTF)(void *);
    void *(*_getRightForeArmTF)(void *);
};

game_sdk_t *game_sdk = new game_sdk_t();

void game_sdk_t::init()
{
    this->GetHp = (int (*)(void *))getRealOffset(oxo("0x1051AAF78"));
    this->Curent_Match = (void *(*)())getRealOffset(oxo("0x101283110"));
    this->GetLocalPlayer = (void *(*)(void *))getRealOffset(oxo("0x101D604D8"));
    this->GetHeadPositions = (void *(*)(void *))getRealOffset(oxo("0x1051C5228"));
    this->get_position = (Vector3(*)(void *))getRealOffset(oxo("0x105FE7CE4"));
    this->Component_GetTransform = (void *(*)(void *))getRealOffset(oxo("0x105F9CC54"));
    this->get_camera = (void *(*)())getRealOffset(oxo("0x105F9A79C"));
    this->WorldToScreenPoint = (Vector3(*)(void *, Vector3))getRealOffset(oxo("0x105F9A154"));
    this->get_isVisible = (bool (*)(void *))getRealOffset(oxo("0x10514A22C"));
    this->get_isLocalTeam = (bool (*)(void *))getRealOffset(oxo("0x10515FFFC"));
    this->get_IsDieing = (bool (*)(void *))getRealOffset(oxo("0x105133838"));
    this->get_MaxHP = (int (*)(void *))getRealOffset(oxo("0x1051AB020"));
    this->GetForward = (Vector3(*)(void *))getRealOffset(oxo("0x105FE8694"));
    this->set_aim = (void (*)(void *, Quaternion))getRealOffset(oxo("0x1051468F0"));
    this->get_IsSighting = (bool (*)(void *))getRealOffset(oxo("0x10513AA94"));
    this->get_IsFiring = (bool (*)(void *))getRealOffset(oxo("0x105135E20"));
    this->name = (monoString * (*)(void *player)) getRealOffset(oxo("0x105141C3C"));

    // skeleton related
    this->_GetHeadPositions  = (void *(*)(void *))getRealOffset(oxo("0x1051C5228"));
    this->_newHipMods        = (void *(*)(void *))getRealOffset(oxo("0x1051C5378"));
    this->_GetLeftAnkleTF    = (void *(*)(void *))getRealOffset(oxo("0x1051C56AC"));
    this->_GetRightAnkleTF   = (void *(*)(void *))getRealOffset(oxo("0x1051C5750"));
    this->_GetLeftToeTF      = (void *(*)(void *))getRealOffset(oxo("0x1051C57F4"));
    this->_GetRightToeTF     = (void *(*)(void *))getRealOffset(oxo("0x1051C5898"));
    this->_getLeftHandTF     = (void *(*)(void *))getRealOffset(oxo("0x105145BD0"));
    this->_getRightHandTF    = (void *(*)(void *))getRealOffset(oxo("0x105145C7C"));
    this->_getLeftForeArmTF  = (void *(*)(void *))getRealOffset(oxo("0x105145D20"));
    this->_getRightForeArmTF = (void *(*)(void *))getRealOffset(oxo("0x105145DC4"));
}

namespace Camera$$WorldToScreen
{
    ImVec2 Regular(Vector3 pos)
    {
        auto cam = game_sdk->get_camera();
        if (!cam)
            return {0, 0};
        Vector3 worldPoint = game_sdk->WorldToScreenPoint(cam, pos);
        if (worldPoint.z < 0.1f) return {-1000, -1000};
        
        int ScreenWidth = ImGui::GetIO().DisplaySize.x;
        int ScreenHeight = ImGui::GetIO().DisplaySize.y;
        
        return {ScreenWidth * worldPoint.x, ScreenHeight * (1.0f - worldPoint.y)};
    }

    ImVec2 Checker(Vector3 pos, bool &checker)
    {
        auto cam = game_sdk->get_camera();
        if (!cam) {
            checker = false;
            return {0, 0};
        }
        Vector3 worldPoint = game_sdk->WorldToScreenPoint(cam, pos);
        checker = (worldPoint.z > 0.1f);
        
        int ScreenWidth = ImGui::GetIO().DisplaySize.x;
        int ScreenHeight = ImGui::GetIO().DisplaySize.y;
        
        return {ScreenWidth * worldPoint.x, ScreenHeight * (1.0f - worldPoint.y)};
    }
}

Vector3 GetBonePosition(void *player, void *(*transformGetter)(void *))
{
    if (!player || !transformGetter)
        return Vector3();
    void *transform = transformGetter(player);
    return transform ? game_sdk->get_position(game_sdk->Component_GetTransform(transform)) : Vector3();
}

Vector3 getPosition(void *transform)
{
    return game_sdk->get_position(game_sdk->Component_GetTransform(transform));
}

static Vector3 GetHeadPosition(void *player)
{
    return game_sdk->get_position(game_sdk->GetHeadPositions(player));
}

// Add these new functions
static Vector3 GetNeckPosition(void *player) {
    return GetBonePosition(player, game_sdk->_GetHeadPositions);
}

static Vector3 GetChestPosition(void *player) {
    return GetBonePosition(player, game_sdk->_newHipMods);
}

static Vector3 CameraMain(void *player)
{
    return game_sdk->get_position(*(void **)((uint64_t)player + oxo("0x318")));
}

Quaternion GetRotationToTheLocation(Vector3 Target, float Height, Vector3 MyEnemy)
{
    return Quaternion::LookRotation((Target + Vector3(0, Height, 0)) - MyEnemy, Vector3(0, 1, 0));
}

#include "Helper/Ext.h"

class tanghinh
{
public:
    static Vector3 Transform_GetPosition(void *player)
    {
        Vector3 out = Vector3::zero();
        void (*_Transform_GetPosition)(void *transform, Vector3 *out) = (void (*)(void *, Vector3 *))getRealOffset(oxo("0x105FE7D14"));
        _Transform_GetPosition(player, &out);
        return out;
    }

    static void *Player_GetHeadCollider(void *player)
    {
        void *(*_Player_GetHeadCollider)(void *players) = (void *(*)(void *))getRealOffset(oxo("0x105144E64"));
        return _Player_GetHeadCollider(player);
    }

    static bool Physics_Raycast(Vector3 camLocation, Vector3 headLocation, unsigned int LayerID, void *collider)
    {
        bool (*_Physics_Raycast)(Vector3 camLocation, Vector3 headLocation, unsigned int LayerID, void *collider) = (bool (*)(Vector3, Vector3, unsigned int, void *))getRealOffset(oxo("0x1046F7568"));
        return _Physics_Raycast(camLocation, headLocation, LayerID, collider);
    }

    static bool isVisible(void *enemy)
    {
        if (enemy != NULL)
        {
            void *hitObj = NULL;
            auto Camera = Transform_GetPosition(game_sdk->Component_GetTransform(game_sdk->get_camera()));
            auto Target = Transform_GetPosition(game_sdk->Component_GetTransform(Player_GetHeadCollider(enemy)));
            return !Physics_Raycast(Camera, Target, 12, &hitObj);
        }
        return false;
    }
};

void DrawSkeleton(void *player, ImDrawList *drawList)
{
    if (!player || !drawList)
        return;
    bool isPlayerVisible = tanghinh::isVisible(player);
    Vector3 headPos = GetBonePosition(player, game_sdk->_GetHeadPositions);
    Vector3 hipPos = GetBonePosition(player, game_sdk->_newHipMods);
    Vector3 leftAnklePos = GetBonePosition(player, game_sdk->_GetLeftAnkleTF);
    Vector3 rightAnklePos = GetBonePosition(player, game_sdk->_GetRightAnkleTF);
    Vector3 leftToePos = GetBonePosition(player, game_sdk->_GetLeftToeTF);
    Vector3 rightToePos = GetBonePosition(player, game_sdk->_GetRightToeTF);
    Vector3 leftHandPos = GetBonePosition(player, game_sdk->_getLeftHandTF);
    Vector3 rightHandPos = GetBonePosition(player, game_sdk->_getRightHandTF);
    Vector3 leftForeArmPos = GetBonePosition(player, game_sdk->_getLeftForeArmTF);
    Vector3 rightForeArmPos = GetBonePosition(player, game_sdk->_getRightForeArmTF);

    bool visible;
    ImVec2 headScreen = Camera$$WorldToScreen::Checker(headPos, visible);
    if (!visible)
        return;

    ImVec2 hipScreen = Camera$$WorldToScreen::Regular(hipPos);
    ImVec2 leftAnkleScreen = Camera$$WorldToScreen::Regular(leftAnklePos);
    ImVec2 rightAnkleScreen = Camera$$WorldToScreen::Regular(rightAnklePos);
    ImVec2 leftToeScreen = Camera$$WorldToScreen::Regular(leftToePos);
    ImVec2 rightToeScreen = Camera$$WorldToScreen::Regular(rightToePos);
    ImVec2 leftHandScreen = Camera$$WorldToScreen::Regular(leftHandPos);
    ImVec2 rightHandScreen = Camera$$WorldToScreen::Regular(rightHandPos);
    ImVec2 leftForeArmScreen = Camera$$WorldToScreen::Regular(leftForeArmPos);
    ImVec2 rightForeArmScreen = Camera$$WorldToScreen::Regular(rightForeArmPos);

    
    ImColor boneColor = ImColor(255, 105, 180, 255);
    float thickness = 0.2f;

    drawList->AddCircle(headScreen, 2.0f, boneColor, 12, thickness);

    drawList->AddLine(headScreen, hipScreen, boneColor, thickness);

    drawList->AddLine(headScreen, leftForeArmScreen, boneColor, thickness);
    drawList->AddLine(headScreen, rightForeArmScreen, boneColor, thickness);
    drawList->AddLine(leftForeArmScreen, leftHandScreen, boneColor, thickness);
    drawList->AddLine(rightForeArmScreen, rightHandScreen, boneColor, thickness);

    drawList->AddLine(hipScreen, leftAnkleScreen, boneColor, thickness);
    drawList->AddLine(hipScreen, rightAnkleScreen, boneColor, thickness);
    drawList->AddLine(leftAnkleScreen, leftToeScreen, boneColor, thickness);
    drawList->AddLine(rightAnkleScreen, rightToeScreen, boneColor, thickness);
}

bool isFov(Vector3 vec1, Vector3 vec2, int radius)
{
    int x = vec1.x;
    int y = vec1.y;
    int x0 = vec2.x;
    int y0 = vec2.y;
    if ((pow(x - x0, 2) + pow(y - y0, 2)) <= pow(radius, 2))
    {
        return true;
    }
    return false;
}

void *GetClosestEnemy()
{
    try
    {
        float shortestDistance = 9999.0f;
        void *closestEnemy = NULL;
        void *get_MatchGame = game_sdk->Curent_Match();
        if (!get_MatchGame)
            return NULL;
        void *LocalPlayer = game_sdk->GetLocalPlayer(get_MatchGame);
        if (!LocalPlayer || !game_sdk->Component_GetTransform(LocalPlayer))
            return NULL;
        if (!Vars.Enable)
            return NULL;
        Dictionary<uint8_t *, void **> *players = *(Dictionary<uint8_t *, void **> **)((long)get_MatchGame + oxo("0x120"));
        if (!players || !players->getValues())
            return NULL;
        for (int u = 0; u < players->getNumValues(); u++)
        {
            void *Player = players->getValues()[u];
            if (!Player)
                continue;
            if (Player == LocalPlayer)
                continue;
            if (!game_sdk->get_MaxHP(Player))
                continue;
            if (game_sdk->get_IsDieing(Player))
                continue;
            if (!game_sdk->get_isVisible(Player))
                continue;
            if (game_sdk->get_isLocalTeam(Player))
                continue;

            int hp = game_sdk->GetHp(Player);
            if (ignoreKnocked && hp <= 0) continue;

            Vector3 PlayerPos = getPosition(Player);
            Vector3 LocalPlayerPos = getPosition(LocalPlayer);
            ImVec2 screenPos = Camera$$WorldToScreen::Regular(PlayerPos);
            bool isFov1 = isFov(Vector3(screenPos.x, screenPos.y), Vector3(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2), Vars.AimFov);
            float distance = Vector3::Distance(LocalPlayerPos, PlayerPos);
            if (distance < 200)
            {
                Vector3 targetDir = Vector3::Normalized(PlayerPos - LocalPlayerPos);
                float angle = Vector3::Angle(targetDir, game_sdk->GetForward(game_sdk->Component_GetTransform(game_sdk->get_camera()))) * 100.0f;
                if (angle <= Vars.AimFov && isFov1 && angle < shortestDistance)
                {
                    if (tanghinh::isVisible(Player))
                    {
                        shortestDistance = angle;
                        closestEnemy = Player;
                    }
                }
            }
        }
        return closestEnemy;
    }
    catch (...)
    {
        return NULL;
    }
}


void ProcessAimbot()
{
    if (!Vars.Aimbot)
        return;
    void *CurrentMatch = game_sdk->Curent_Match();
    if (!CurrentMatch)
        return;
    void *LocalPlayer = game_sdk->GetLocalPlayer(CurrentMatch);
    if (!LocalPlayer || !game_sdk->Component_GetTransform(LocalPlayer))
        return;
    if (game_sdk->get_IsDieing(LocalPlayer))
        return;
    void *closestEnemy = GetClosestEnemy();
    if (!closestEnemy || !game_sdk->Component_GetTransform(closestEnemy))
        return;
    if (game_sdk->get_IsDieing(closestEnemy))
        return;
    if (!game_sdk->get_isVisible(closestEnemy))
        return;

    Vector3 EnemyLocation;
    switch(Vars.Target) {
        case HEADv2: 
            EnemyLocation = GetBonePosition(closestEnemy, game_sdk->_GetHeadPositions); 
            break;
        case BODY: 
            EnemyLocation = GetBonePosition(closestEnemy, game_sdk->_newHipMods); 
            break;
        default: 
            EnemyLocation = GetHeadPosition(closestEnemy); 
            break;
    }
    if (EnemyLocation == Vector3::zero())
        return;

    Vector3 PlayerLocation = CameraMain(LocalPlayer);
    if (PlayerLocation == Vector3::zero())
        return;

    Quaternion PlayerLook = GetRotationToTheLocation(EnemyLocation, 0.1f, PlayerLocation);

    bool IsScopeOn = game_sdk->get_IsSighting(LocalPlayer);
    bool IsFiring = game_sdk->get_IsFiring(LocalPlayer);

    bool shouldAim =
        (Vars.AimWhen == 0) ||
        (Vars.AimWhen == 1 && IsFiring) ||
        (Vars.AimWhen == 2 && IsScopeOn);

    if (shouldAim)
    {
        game_sdk->set_aim(LocalPlayer, PlayerLook);
    }
}

void get_players()
{
    ImDrawList *draw_list = ImGui::GetBackgroundDrawList();
    if (!draw_list)
        return;
    if (!Vars.Enable)
        return;

    try
    {
        ProcessAimbot();

        void *current_Match = game_sdk->Curent_Match();
        if (!current_Match)
            return;

        void *local_player = game_sdk->GetLocalPlayer(current_Match);
        if (!local_player)
            return;

        Dictionary<uint8_t *, void **> *players = *(Dictionary<uint8_t *, void **> **)((long)current_Match + 0x120);
        if (!players || !players->getValues())
            return;

        void *camera = game_sdk->get_camera();
        if (!camera)
            return;

        int enemies_in_range = 0;
        for (int u = 0; u < players->getNumValues(); u++)
        {
            void *closestEnemy = players->getValues()[u];
            if (!closestEnemy)
                continue;
            if (!game_sdk->Component_GetTransform(closestEnemy))
                continue;
            if (closestEnemy == local_player)
                continue;
            if (!game_sdk->get_MaxHP(closestEnemy))
                continue;
            if (game_sdk->get_IsDieing(closestEnemy))
                continue;
            if (!game_sdk->get_isVisible(closestEnemy))
                continue;
            if (game_sdk->get_isLocalTeam(closestEnemy))
                continue;

            Vector3 pos = getPosition(closestEnemy);
            Vector3 pos2 = getPosition(local_player);
            float distance = Vector3::Distance(pos, pos2);
            if (distance > 200.0f)
                continue;

            ImColor dyn = ImColor(Vars.espColor[0], Vars.espColor[1], Vars.espColor[2], Vars.espColor[3]);

            bool w2sc;
            ImVec2 top_pos = Camera$$WorldToScreen::Regular(pos + Vector3(0, 1.6, 0));
            ImVec2 bot_pos = Camera$$WorldToScreen::Regular(pos);
            ImVec2 pos_3 = Camera$$WorldToScreen::Checker(pos, w2sc);
            auto pmtXtop = top_pos.x;
            auto pmtXbottom = bot_pos.x;
            if (top_pos.x > bot_pos.x)
            {
                pmtXtop = bot_pos.x;
                pmtXbottom = top_pos.x;
            }
            Camera$$WorldToScreen::Checker(pos + Vector3(0, 0.75f, 0), w2sc);
            float calculatedPosition = fabs((top_pos.y - bot_pos.y) * (0.0092f / 0.019f) / 2);

            ImRect rect(
                ImVec2(pmtXtop - calculatedPosition, top_pos.y),
                ImVec2(pmtXbottom + calculatedPosition, bot_pos.y));

                    const auto &viewpos = game_sdk->get_position(game_sdk->Component_GetTransform(game_sdk->get_camera()));

        // 1. LUÔN HIỆN TÊN TRÊN ĐỈNH KHI BẬT LINE
        if (Vars.lines) 
        {
            ImVec2 logo_pos = ImVec2(ImGui::GetIO().DisplaySize.x / 2, 20);
            float text_width = ImGui::CalcTextSize(oxorany("Tele:@mriosnhatvip")).x;
            logo_pos.x -= text_width / 2;
            ImGui::GetBackgroundDrawList()->AddText(NULL, 18.0f, logo_pos, ImColor(255, 105, 180, 255), oxorany("Tele:@mriosnhatvip"));
        }

        // 2. VẼ ESP CHO ĐỊCH (NẰM TRONG VÒNG LẶP)
        if (w2sc) 
        {
            if (Vars.lines)
            {
                // Line từ đỉnh xuống đầu địch (Màu hồng kem)
                ImGui::GetBackgroundDrawList()->AddLine(ImVec2(ImGui::GetIO().DisplaySize.x / 2, 0), ImVec2(top_pos.x, top_pos.y), ImColor(255, 182, 193, 255), 0.2f);
            }

    }
        // 2. VẼ ESP CHO ĐỊCH (NẰM TRONG VÒNG LẶP)
        if (w2sc) 
        {
            if (Vars.lines)
            {
                // Line từ đỉnh xuống đầu địch
                ImGui::GetBackgroundDrawList()->AddLine(ImVec2(ImGui::GetIO().DisplaySize.x / 2, 0), ImVec2(top_pos.x, top_pos.y), ImColor(255, 182, 193, 255), 0.2f);
            }

     

                if (Vars.Box)
                {
                    draw_list->AddRect(rect.Min, rect.Max, ImColor(170, 255, 190, 255), 0.0f, 0, 0.5f);

                    if (Vars.Outline)
                    {
                        draw_list->AddRect(rect.Min - ImVec2(1, 1), rect.Max + ImVec2(1, 1), ImColor(170, 255, 190, 100), 0.0f, 0, 0.3f);
                        draw_list->AddRect(rect.Min + ImVec2(1, 1), rect.Max - ImVec2(1, 1), ImColor(170, 255, 190, 100), 0.0f, 0, 0.3f);
                    }
                }
                if (Vars.Name && verdana_smol)
                {
                    auto pname = game_sdk->name(closestEnemy);
                    std::string names = "DlvXx";
                    if (pname && (uintptr_t)pname > 0x1000) {
                        names = pname->toCPPString();
                    }
                    
                    ImVec2 text_size = verdana_smol->CalcTextSizeA(15.0f, FLT_MAX, 0, names.c_str());
                    ImVec2 name_pos = {
                        rect.Min.x + (rect.GetWidth() / 2) - text_size.x / 2,
                        rect.Min.y - 5 - text_size.y};
                    
                    AddText(verdana_smol, 9.0f, true, true, name_pos, ImColor(255, 105, 180, 255), names.c_str(), draw_list);

                }
                if (Vars.Health && pixel_smol)
                {
                    int health = game_sdk->GetHp(closestEnemy);
                    int maxhealth = game_sdk->get_MaxHP(closestEnemy);
                    if (maxhealth <= 0) maxhealth = 100;
                    float health_multiplier = (float)health / (float)maxhealth;
                    health_multiplier = std::clamp(health_multiplier, 0.0f, 1.0f);
                    
                    float health_bar_pos = rect.Min.x - 6;
                    float height = rect.Max.y - rect.Min.y;

                    //draw_list->AddRectFilled({health_bar_pos - 1, rect.Min.y - 1}, {health_bar_pos + 3, rect.Max.y + 1}, ImColor(0, 0, 0, 150));
                    draw_list->AddRectFilled({health_bar_pos + 2, rect.Max.y}, {health_bar_pos + 3, rect.Max.y - (height * health_multiplier)}, ImColor(255, 182, 193, 255));

                    //std::string hpstr = string_format("%d", health);
                    //ImVec2 text_size_hp = pixel_smol->CalcTextSizeA(12.0f, FLT_MAX, 0, hpstr.c_str());
                    //ImVec2 text_pos = {
                        //rect.Min.x + (rect.GetWidth() / 2) - text_size_hp.x / 2,
                        //rect.Max.y + 2};
                    //AddText(pixel_smol, 12.0f, true, true, text_pos, ImColor(0, 255, 0, 255), hpstr, draw_list);
                }

                if (Vars.circlepos)
                {
                    Draw3DCircle(pos, 1.0f, 0.5f, dyn, 36, false, 0.5f);
                }
                if (Vars.skeleton)
                {
                    DrawSkeleton(closestEnemy, draw_list);
                }
            }
            if (Vars.OOF)
            {
                if ((pos_3.x < 0 || pos_3.x > disp.width) || (pos_3.y < 0 || pos_3.y > disp.height) || !w2sc)
                {
                    constexpr int maxpixels = 150;
                    int pixels = maxpixels;
                    if (w2sc)
                    {
                        if (pos_3.x < 0)
                            pixels = clamp((int)-pos_3.x, 0, (int)maxpixels);
                        if (pos_3.y < 0)
                            pixels = clamp((int)-pos_3.y, 0, (int)maxpixels);

                        if (pos_3.x > disp.width)
                            pixels = clamp((int)pos_3.x - (int)disp.width, 0, (int)maxpixels);
                        if (pos_3.y > disp.height)
                            pixels = clamp((int)pos_3.y - (int)disp.height, 0, (int)maxpixels);
                    }

                    float opacity = (float)pixels / (float)maxpixels;

                    float size = 3.5f;
                    Vector3 viewdir = game_sdk->GetForward(game_sdk->Component_GetTransform(game_sdk->get_camera()));
                    Vector3 targetdir = Vector3::Normalized(pos - viewpos);

                    float viewangle = atan2(viewdir.z, viewdir.x) * Rad2Deg;
                    float targetangle = atan2(targetdir.z, targetdir.x) * Rad2Deg;

                    if (viewangle < 0)
                        viewangle += 360;
                    if (targetangle < 0)
                        targetangle += 360;

                    float angle = targetangle - viewangle;

                    while (angle < 0)
                        angle += 360;
                    while (angle > 360)
                        angle -= 360;

                    angle = 360 - angle;
                    angle -= 90;

                    ImColor oofCol = ImColor(Vars.espColor[0], Vars.espColor[1], Vars.espColor[2], opacity);
                    OtFovV1(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2, 90 + distance * 2,
                            angle - size,
                            angle + size,
                            oofCol, 1);
                }
            }
            enemies_in_range++;
        }

        if (Vars.enemycount && enemies_in_range > 0)
        {
            std::string count_str = string_format(oxorany("ENEMIES :%d"), enemies_in_range);
            ImVec2 count_pos = { ImGui::GetIO().DisplaySize.x * 0.35f, 40 }; 
            ImColor red_col = ImColor(255, 0, 0, 255);
            AddText(pixel_big, 20, false, true, count_pos, red_col, count_str, draw_list);
        }
    }
    catch (...)
    {
        return;
    }
}

void aimbot()
{
    ImVec2 center = ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2);
    if (!Vars.Aimbot)
        return;
    ImDrawList *draw_list = ImGui::GetBackgroundDrawList();
    if (!draw_list)
        return;
    void *Match = game_sdk->Curent_Match();
    if (!Match)
        return;

    if (Vars.isAimFov)
    {
        ImColor fovCol = ImColor(170, 255, 190, 255); 
        if (Vars.fovaimglow)
            drawcircleglow(draw_list, center, Vars.AimFov, fovCol, 999, 1, 12);
        else
            draw_list->AddCircle(center, Vars.AimFov, fovCol, 100, 1.0f);
    }

    void *LocalPlayer = game_sdk->GetLocalPlayer(Match);
    if (!LocalPlayer)
        return;
    void *playertarget = GetClosestEnemy();
    if (!playertarget)
        return;

    ImVec2 EnemyLocation = Camera$$WorldToScreen::Regular(GetHeadPosition(playertarget));
    drawlineglow(draw_list, ImVec2(center.x, center.y), EnemyLocation, GetRainbowColor(1.0f), 1, 3);
}

void draw_watermark()
{
   /* std::string claw = oxorany("VanNghiaaMOD");
    ImVec2 text_size = verdana_smol->CalcTextSizeA(16.0f, FLT_MAX, 0, claw.c_str());
    ImVec2 text_pos(
        10, // Left margin
        ImGui::GetIO().DisplaySize.y - text_size.y - 10); // Bottom margin

    AddText(verdana_smol, 16, false, false, text_pos + ImVec2(1, 1), ImColor(0, 0, 0, 150), claw);

    ImColor rainbow = GetRainbowColor(1.0f, 0.9f, 0.9f);
    AddText(verdana_smol, 16, false, false, text_pos, rainbow, claw);

    ImDrawList *draw_list = ImGui::GetBackgroundDrawList();
    draw_list->AddLine(
        ImVec2(text_pos.x, text_pos.y + text_size.y + 2),
        ImVec2(text_pos.x + text_size.x, text_pos.y + text_size.y + 2),
        rainbow,
        2.0f);*/
}
// end of the code